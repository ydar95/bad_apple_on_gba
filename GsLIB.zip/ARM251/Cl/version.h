/* version.h: defines library version string                   */
/* Copyright (C) Advanced Risc Machines Ltd., 1991              */

#define __LIB_ISSUE "4.01"
