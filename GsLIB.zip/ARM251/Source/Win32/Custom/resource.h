
// $Revision: 1.4.2.1 $
//   $Author: dcleland $
//     $Date: 1998/12/09 21:57:24 $
//
// Copyright (c) Advanced RISC Machines Ltd 1997


//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by custom.rc
//

//removed IDS_MDWLINEn and IDS_WINDBGLINEn dearlam


#define IDS_ADWLINE1                 2

#define IDS_ADWLINE2                 4

#define IDS_ADWLINE3                 6

#define IDS_APMLINE1                    1

#define IDS_APMLINE2                    3

#define IDS_APMLINE3                    5

#define IDS_PACKAGE                     7
#define IDS_PACKAGE_VERSION             8
#define IDS_PACKAGE_NAME_VERSION        9
#define IDS_COMPANY                     10
#define IDS_COMPANY_COPYRIGHT           11

#define IDR_APMCUSTICON                 104
#define IDR_WINDBGCUSTICON              105

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
