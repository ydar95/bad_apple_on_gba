/*
 * RCS $Revision: 1.3 $
 * Checkin $Date: 1998/07/23 12:18:25 $
 * Revising $Author: dearlam $
 */

#include <windows.h>

//dearlam - let it match the documented prototype function

BOOL WINAPI DllMain(HANDLE hInstance,
                    ULONG ul_reason_for_call,
                    LPVOID lpReserved)

{
        return TRUE;
}

