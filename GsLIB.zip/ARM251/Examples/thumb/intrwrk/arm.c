#include <stdio.h>

void arm_function(void)
{
    printf("Hello from ARM world\n");
}
