#ifndef __int64_h
#define __int64_h

typedef struct int64_struct {
  unsigned int lo;
  unsigned int hi;
} int64;

#endif
