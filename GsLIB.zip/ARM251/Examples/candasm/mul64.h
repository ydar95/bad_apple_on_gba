/* Declaration of mul64, specifying that the int64 */
#include "int64.h"

__value_in_regs extern int64 mul64(unsigned a, unsigned b);
