/*
dummy file for AGBGFXConverter, so it stays happy.
ignore this.
*/